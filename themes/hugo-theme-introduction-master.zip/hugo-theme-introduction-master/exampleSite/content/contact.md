---
title: "Contact"
date: 2017-03-09T13:23:28+08:00
---

In the Contact section of Introduction, you may optionally display the current time in your preferred timezone.

This lets visitors know what sort of response time to expect when they contact you. The timezone is easily set in the config file.
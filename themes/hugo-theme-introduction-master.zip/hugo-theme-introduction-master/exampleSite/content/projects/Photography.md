---
title: "Photography"
date: 2017-11-13T12:21:21-05:00
image: "img/camera.jpg"
external_link: ""
weight: 1
---

## Sometimes I take pictures.

This project is about the pictures I take. Sometimes, they are pictures of cats.
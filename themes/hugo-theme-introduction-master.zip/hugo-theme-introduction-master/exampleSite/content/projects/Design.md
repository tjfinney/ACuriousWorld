---
title: "Design"
date: 2017-11-13T12:21:16-05:00
image: "img/plant.jpg"
external_link: ""
weight: 2
---

This theme was designed by [Vicky Lai](https://vickylai.io). Go on, explore! 💪

If you want to use it for your website, check out the section at the bottom of the main page. 👍
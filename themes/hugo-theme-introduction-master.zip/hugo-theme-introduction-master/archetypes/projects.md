---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
image: ""
external_link: ""
weight:
draft: true
---